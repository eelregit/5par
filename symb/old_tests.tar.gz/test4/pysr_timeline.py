#!/usr/bin/env python

#SBATCH --job-name=symb
#SBATCH --output=%x-%j.out
#SBATCH --partition=ccm
#SBATCH --constraint=icelake
#SBATCH --nodes=1
#SBATCH --exclusive
#SBATCH --time=7-00:00:00


import os

import numpy as np
import sympy
import pysr
from pysr import PySRRegressor


num_cores = os.environ['SLURM_CPUS_ON_NODE']
print(f'num of cores is {num_cores}', flush=True)

model = PySRRegressor(
    # Search Space & Complexity
    binary_operators=['+', '-', '*', '/', 'pow'],
    unary_operators=['exp', 'log', 'tanh', 'atan', 'alg_sgmd(x) = x/sqrt(x^2+1)'],
    extra_sympy_mappings={'alg_sgmd': lambda x: x / sympy.sqrt(x**2 + 1)},
    maxsize=25,
    constraints={'pow':(-1,4), 'exp':4, 'log':4},
    nested_constraints={
        'exp':{'exp':0, 'log':1},
        'log':{'exp':1, 'log':0},
        'tanh':{'tanh':0, 'atan':0, 'alg_sgmd':0},
        'atan':{'tanh':1, 'atan':0, 'alg_sgmd':0},
        'alg_sgmd':{'tanh':0, 'atan':0, 'alg_sgmd':0},
    },
    #warmup_maxsize_by=0.1,
    adaptive_parsimony_scaling=20, # increase if simpler expression remain stagnant

    # Search Size
    niterations=1000000,
    early_stop_condition=('stop_if(loss, complexity) = loss < 1e-6 && complexity < 10'),
    populations=num_cores * 2,
    ncyclesperiteration=10000,
    weight_optimize=0.01,

    # Performance and Parallelization
    procs=num_cores,
    multithreading=False,
    cluster_manager='slurm',
    batching=True,
    turbo=True,
    #warm_start=True,

    # Monitoring
    verbosity=1,
    print_precision=2,
    progress=False,
)

# full N=128 data
v_128 = np.loadtxt('./data_xHI.txt', usecols=[0,2,3,4,5,6,7,8])
d_128 = np.loadtxt('./data_xHI.txt', usecols=[1])

vt_64, vc_64 = np.array_split(v_128,2)
dt_64, dc_64 = np.array_split(d_128,2)

model.fit(vt_64,dt_64)
#pysr.sr.Main.eval('flush(stdout)')
