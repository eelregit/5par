#!/usr/bin/env python

#SBATCH --job-name=symb
#SBATCH --output=%x-%j.out
#SBATCH --partition=ccm
#SBATCH --constraint=icelake
#SBATCH --nodes=4
#SBATCH --exclusive
#SBATCH --time=7-00:00:00


import os
import sys

import numpy as np
import sympy
import pysr


num_nodes = int(os.environ['SLURM_NNODES'])
num_cores = int(os.environ['SLURM_CPUS_ON_NODE'])
print(f'{num_cores} cores on each of {num_nodes} nodes', flush=True)
num_cores *= num_nodes


#HACK the last column was originally z_mid, but is now used for a hack
#     1. it's replaced by the rescaled scale factor below
#v_names = ['lnar', 's8', 'ns', 'h', 'Ob', 'Om', 'zt', 'ar']
#     2. it's replaced by a tweak factor below
v_names = ['lnar', 's8', 'ns', 'h', 'Ob', 'Om', 'zt', 'tweak']
v_128 = np.loadtxt('../data_xHI_a.txt', dtype='f4', usecols=[0, 2, 3, 4, 5, 6, 7, 8])
d_128 = np.loadtxt('../data_xHI_a.txt', dtype='f4', usecols=[1])

vt_64, vc_64 = np.array_split(v_128,2)
dt_64, dc_64 = np.array_split(d_128,2)


objective = """
function custom_obj(tree::Node{T}, dataset::Dataset{T,L}, options::Options, idx=nothing)::L where {T,L}
    tree.degree != 2 && return convert(L, 10^8)
    shape_tree = tree.l
    params_tree = tree.r
    shape_tree.degree != 2 && return convert(L, 10)
    tweak_tree = shape_tree.r
    shape_tree = shape_tree.l
    params_tree.degree != 2 && return convert(L, 10)
    pivot_tree = params_tree.l
    tilt_tree = params_tree.r

    #HACK dummy feature, because the trees assume size(dataset.X, 1) features
    num_feat, batch_size = size(dataset.X)
    X = cat(zeros(Float32, 1, batch_size), dataset.X[2:end-1, :], zeros(Float32, 1, batch_size), dims=1)
    ln_pivot, flag = eval_tree_array(pivot_tree, X, options)
    !flag && return convert(L, Inf)
    tilt, flag = eval_tree_array(tilt_tree, X, options)
    !flag && return convert(L, Inf)
    tweak, flag = eval_tree_array(tweak_tree, X, options)
    !flag && return convert(L, Inf)

    # assuming universal shape as a function of the rescaled scale factor
    #HACK include both linear and log rescaled a
    #OTHER HACK include log rescaled a and a "tweak" parameter to the universal shape
    a = dataset.X[1, :]
    lnar = @. (log(a) - ln_pivot) * tilt
    #ar = exp.(lnar)
    #lnar = cat(reshape(lnar, 1, :), zeros(Float32, num_feat - 2, batch_size), reshape(ar, 1, :), dims=1)
    lnar = cat(reshape(lnar, 1, :), zeros(Float32, num_feat - 2, batch_size), reshape(tweak, 1, :), dims=1)

    pred, flag = eval_tree_array(shape_tree, lnar, options)
    !flag && return convert(L, Inf)

    #pred = @. exp(- exp(pred))  # forcing Gompertz

    res = pred .- dataset.y
    #w = minimum(1e-2, dataset.y, (1 .- dataset.y))  # suppression near 0 & 1
    #loss = sum(@. w * res ^ 2) / sum(w)
    loss = sum(res .^ 2) / length(res)

    # we want fewer sigmoid in the universal shape for interpretability
    #num = count(node -> node.degree == 1 && node.op == 5, shape_tree)
    #loss += convert(L, 1e-4 * num)

    # we want no sigmoid in the pivot or tilt
    #num = count(node -> node.degree == 1 && node.op == 5, pivot_tree)
    #num += count(node -> node.degree == 1 && node.op == 5, tilt_tree)
    #loss += convert(L, 1e-4 * num)

    return loss
end
"""

kwargs = dict(
    # Search Space, Complexity, & Objective
    binary_operators=['+', '-', '*', '/', '^'],
    unary_operators=['exp', 'log', 'Gom(x) = exp(- exp(x))'],
    #unary_operators=['neg', 'inv(x) = 1/x', 'exp', 'log'],
    extra_sympy_mappings={
        #'inv': lambda x: 1 / x,
        'Gom': lambda x: sympy.exp(- sympy.exp(x)),
        #'tanh_p1': lambda x: sympy.tanh(x) + 1,  # this helped us to discover the Gompertz
        #'atan_p1': lambda x: sympy.atan(x) + 1,  # empirically rare
        #'alg_sgmd': lambda x: x / sympy.sqrt(x**2 + 1)
    },
    #complexity_of_operators={'neg': 0.5, 'inv': 0.5},
    complexity_of_operators={'Gom': 2},
    #complexity_of_constants=0.2,
    #complexity_of_variables=0.2,
    #constraints={'^':(-1, 4), 'exp':4, 'log':4},
    #nested_constraints={
    #    'exp':{'exp':0, 'log':1},
    #    'log':{'exp':1, 'log':0},
    #},
    maxsize=40,
    #maxdepth=8,
    #warmup_maxsize_by=1e-2,
    parsimony=1e-6,
    adaptive_parsimony_scaling=1000,
    full_objective=objective,

    # Search Size
    niterations=10000,
    early_stop_condition=('stop_if(loss, complexity) = loss < 1e-5 && complexity < 21'),
    populations=num_cores*4,
    ncyclesperiteration=10000,

    # Mutations
    weight_simplify=0.01,
    weight_optimize=0.001,

    # Performance & Parallelization
    procs=num_cores,
    cluster_manager='slurm',
    batching=True,
    batch_size=100,
    turbo=True,

    # Monitoring
    verbosity=1,
    print_precision=2,
    progress=False,
)

try:
    model = pysr.PySRRegressor.from_file(sys.argv[1], warm_start=True, **kwargs)
    model.refresh()
except IndexError:
    model = pysr.PySRRegressor(**kwargs)

model.fit(vt_64,dt_64, variable_names=v_names)
#pysr.sr.Main.eval('flush(stdout)')
